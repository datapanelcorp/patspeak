#!/home/j/roi/bin/python
# pscp .\roie.py j@picando:/home/j
import can
import serial
import subprocess
import threading
import time
import pyvisa
import sys
from gpiozero import LED
import shutil
import os
import fnmatch

# --- Constants ---
# Hardware identifiers
MULTI_METER_PATH = '/dev/ttyUSB0'
MULTI_METER_BAUD = 38400
#ELOAD_VISA_ID = "USB0::11975::34816::802197042747610014::0::INSTR"
#ELOAD_VISA_ID = "USB0::11975::34816::802197042787270012::0::INSTR"
ELOAD_VISA_ID = "USB0::11975::34816::*::0::INSTR"
# Data Panel E-Load has BOID v1.10
# MULTI-METER ID: 5491B Multimeter,Ver1.1.11.11.23,124E12115

# CAN bus configuration
CAN_CHANNEL = "can1"
CAN_BITRATE = 250000
LOAD_CTRL_ID = 0x0CFF0400
MMETER_CTRL_ID = 0x0CFF0600  # could this be 0x0CFF0200?
RLY_CTRL_ID = 0x0CFF0500
ELOAD_READ_ID = 0x0CFF0003
MMETER_READ_ID = 0x0CFF0004

# Pin configuration
K1_PIN_BCM = 26
DefaultState = False#True
GPIO_K1 = LED(K1_PIN_BCM, initial_value=DefaultState)

# --- Class for Hardware Management ---
class HardwareManager:
    """Manages communication and state for the e-load and multimeter."""

    def __init__(self):
        # e-load state
        self.e_load_remote: int = 0
        self.e_load_enabled: int = 0
        self.e_load_mode: int = 0
        self.e_load_short: int = 0
        self.e_load_csetting: int = 0
        self.e_load_rsetting: int = 0
        self.pload_volts: float = 0.0
        self.pload_current: float = 0.0

        # multimeter state
        self.multi_meter = None
        self.multi_meter_mode: int = 0
        self.multi_meter_range: int = 0
        self.mmeter_id = None

        # VISA
        self.e_load = None
        self.resource_manager = None

        # Locks (only for SCPI instruments). Drop CAN lock entirely.
        self.eload_lock = threading.Lock()
        self.mmeter_lock = threading.Lock()

    def initialize_devices(self) -> None:
        """Initializes the multi-meter and e-load."""
        self._initialize_multimeter()
        self._initialize_eload()

    def _initialize_multimeter(self) -> None:
        """Initializes the multimeter via serial connection."""
        try:
            mmeter = serial.Serial(MULTI_METER_PATH, MULTI_METER_BAUD, timeout=1)
            mmeter.write(b'*IDN?\n')
            self.mmeter_id = mmeter.readline().decode().strip()
            print(f"MULTI-METER ID: {self.mmeter_id}")
            self.multi_meter = mmeter
        except (serial.SerialException, IOError) as e:
            print(f"Failed to communicate with multi-meter: {e}")
            self.multi_meter = None

    def _initialize_eload(self) -> None:
        """Initializes the e-load via pyvisa."""
        try:
            self.resource_manager = pyvisa.ResourceManager()
            available_resources = self.resource_manager.list_resources()
            if not available_resources:
                print("No VISA resources found.")
                return
            print("Available VISA resource IDs:")
            for resource_id in available_resources:
                print(f"- {resource_id}")
            for resource_id in available_resources:
                if fnmatch.fnmatch(resource_id, ELOAD_VISA_ID):
                    eload = self.resource_manager.open_resource(resource_id)
                    print(f"E-LOAD ID: {eload.query('*IDN?')}")
                    print(f"Resetting {ELOAD_VISA_ID}")
                    eload.write('*RST')
                    eload.write('SYST:CLE')
                    self.e_load = eload
                    break
            if not self.e_load:
                print("No matching e-load VISA resource opened.")
        except Exception as e:
            print(f"An error occurred with the e-load via Resource Manager: {e}")
            self.e_load = None

    def close_devices(self) -> None:
        """Closes connections to all hardware devices."""
        if self.multi_meter:
            print("Closing multi-meter connection...")
            self.multi_meter.close()
        if self.e_load:
            print("Closing e-load connection...")
            self.e_load.close()
        if self.resource_manager:
            print("Closing resource manager...")
            self.resource_manager.close()

# --- Display helper ---
def update_display(lines):
    """
    Clears the entire terminal and prints the new content, filling all rows.
    Hides the cursor during the update to prevent flickering.
    Args:
        lines (list): A list of strings to print.
    """
    try:
        size = os.get_terminal_size()
    except OSError:
        size = os.terminal_size((80, 24))

    # Hide cursor
    sys.stdout.write("\033[?25l")
    # Reset and clear screen
    sys.stdout.write("\033[0m\033[H\033[2J")
    for line in lines:
        sys.stdout.write(str(line) + "\n")
    for _ in range(size.lines - len(lines) - 1):
        sys.stdout.write("\n")
    # Show cursor
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()

# --- CAN setup ---
def setup_can_interface(channel: str, bitrate: int) -> can.BusABC | None:
    """Configures and brings up the CAN interface."""
    try:
        # Bring up interface. Ensure this command runs without prompting for password.
        subprocess.run(
            ["sudo", "ip", "link", "set", channel, "up", "type", "can", f"bitrate", f"{bitrate}"],
            check=True
        )
        print(f"CAN interface {channel} is up with bitrate {bitrate}.")
        # python-can Bus is thread-safe; we will not use a global CAN lock.
        return can.interface.Bus(interface='socketcan', channel=channel, bitrate=bitrate)
    except subprocess.CalledProcessError as e:
        print(f"Failed to bring up CAN interface: {e}")
        return None
    except can.CanError as e:
        print(f"Failed to connect to CAN bus: {e}")
        return None


def shutdown_can_interface(channel: str) -> None:
    """Brings down the CAN interface."""
    try:
        subprocess.run(["sudo", "ip", "link", "set", channel, "down"], check=True)
        print(f"CAN interface {channel} is now down.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to bring down CAN interface: {e}")


# --- CAN receiver thread ---
def receive_can_messages(cbus: can.BusABC, hardware: HardwareManager, stop_event: threading.Event) -> None:
    """Continuously receives CAN messages and updates hardware state."""
    print("Receiver thread started. Listening for CAN messages...")
    while not stop_event.is_set():
        # DO NOT hold any lock while blocking on recv()
        message = cbus.recv(timeout=1.0)
        if not message:
            continue

        # Relay control
        if message.arbitration_id == RLY_CTRL_ID:
            if(DefaultState):
                GPIO_K1.off() if message.data[0] & 0x03 == 0x01 else GPIO_K1.on()
            else:
                 GPIO_K1.on() if message.data[0] & 0x03 == 0x01 else GPIO_K1.off()
            continue

        # Multimeter control
        if message.arbitration_id == MMETER_CTRL_ID:
            meter_mode = message.data[0]
            meter_range = message.data[1]

            # Apply function changes only when needed; no readline after non-query
            if hardware.multi_meter and (hardware.multi_meter_mode != meter_mode):
                with hardware.mmeter_lock:
                    if meter_mode == 0:
                        hardware.multi_meter.write(b'FUNC VOLT:DC\n')
                    elif meter_mode == 1:
                        hardware.multi_meter.write(b'FUNC CURR:DC\n')
                        # Optional: set a fixed current range; remove any blocking reads
                        hardware.multi_meter.write(b'CURR:DC:RANG 5\n')
                hardware.multi_meter_mode = meter_mode

            # Track range value without extra queries
            hardware.multi_meter_range = meter_range
            continue

        # E-load control
        if message.arbitration_id == LOAD_CTRL_ID and hardware.e_load:
            first_byte = message.data[0]

            # Remote state
            new_remote_state = 1 if first_byte & 0x03 == 0x01 else 0
            if hardware.e_load_remote != new_remote_state:
                hardware.e_load_remote = new_remote_state
                # Many instruments switch remote with SYST:REM / LOC; left out unless required

            # Enable state
            new_enable_state = 1 if first_byte & 0x0C == 0x04 else 0
            if hardware.e_load_enabled != new_enable_state:
                hardware.e_load_enabled = new_enable_state
                command = "INP ON" if hardware.e_load_enabled else "INP OFF"
                with hardware.eload_lock:
                    hardware.e_load.write(command)

            # Mode (RES vs CURR)
            new_mode = 1 if first_byte & 0x30 == 0x10 else 0
            if hardware.e_load_mode != new_mode:
                hardware.e_load_mode = new_mode
                command = "FUNC RES" if hardware.e_load_mode else "FUNC CURR"
                with hardware.eload_lock:
                    hardware.e_load.write(command)

            # Short circuit enable
            new_short = 1 if first_byte & 0xC0 == 0x40 else 0
            if hardware.e_load_short != new_short:
                hardware.e_load_short = new_short
                command = "INP:SHOR ON" if hardware.e_load_short else "INP:SHOR OFF"
                with hardware.eload_lock:
                    hardware.e_load.write(command)

            # Current setting (little-endian bytes 2-3)
            in_value_c = (message.data[3] << 8) | message.data[2]
            if hardware.e_load_csetting != in_value_c:
                hardware.e_load_csetting = in_value_c
                with hardware.eload_lock:
                    hardware.e_load.write(f"CURR {hardware.e_load_csetting / 1000}")

            # Resistance setting (little-endian bytes 4-5)
            in_value_r = (message.data[5] << 8) | message.data[4]
            if hardware.e_load_rsetting != in_value_r:
                hardware.e_load_rsetting = in_value_r
                with hardware.eload_lock:
                    hardware.e_load.write(f"RES {hardware.e_load_rsetting / 1000}")


# --- Helpers ---
def is_number(value: str) -> bool:
    """Checks if a string can be converted to a float."""
    try:
        float(value)
        return True
    except ValueError:
        return False


# --- Main ---
def main() -> None:
    """Main execution function."""
    hardware = HardwareManager()
    stop_event = threading.Event()
    cbus = None
    receiver_thread = None

    # measurements
    meter_current_mA = 0
    load_volts_mV = 0
    load_current_mA = 0

    # status strings
    load_stat_func = ""
    load_stat_curr = ""
    load_stat_imp = ""
    load_stat_res = ""
    load_stat_short = ""
    meter_mode_str = ""
    meter_range_str = ""

    # query pacing
    last_status_poll = 0.0
    STATUS_POLL_PERIOD = 0.5  # seconds; reduce SCPI spam

    try:
        hardware.initialize_devices()

        cbus = setup_can_interface(CAN_CHANNEL, CAN_BITRATE)
        if not cbus:
            print("Exiting due to CAN interface setup failure.")
            return

        receiver_thread = threading.Thread(
            target=receive_can_messages,
            args=(cbus, hardware, stop_event),
            daemon=True
        )
        receiver_thread.start()

        while True:
            # Read from multimeter and send to CAN
            if hardware.multi_meter:
                with hardware.mmeter_lock:
                    hardware.multi_meter.write(b'FETC?\n')
                    response = hardware.multi_meter.readline().decode().strip()
                if is_number(response):
                    value = float(response)
                    if value < 0:
                        value = 0.0
                    # Assuming current mode most of the time; value in A
                    meter_current_mA = int(round(value * 1000))
                    lo = meter_current_mA & 0xFF
                    hi = (meter_current_mA >> 8) & 0xFF
                    msg = can.Message(
                        arbitration_id=MMETER_READ_ID,
                        data=[lo, hi, 0, 0, 0, 0, 0, 0],
                        is_extended_id=True
                    )
                    try:
                        cbus.send(msg)  # no CAN lock
                    except can.CanError:
                        print("MMeter message NOT sent")

            # Read from e-load and send to CAN
            if hardware.e_load:
                try:
                    # fast measurements
                    with hardware.eload_lock:
                        load_volts_str = hardware.e_load.query("MEAS:VOLT?").strip()
                        load_current_str = hardware.e_load.query("MEAS:CURR?").strip()
                except pyvisa.VisaIOError as e:
                    print(f"PyVISA communication error: {e}", file=sys.stderr)
                    time.sleep(0.1)
                    # skip this cycle
                    load_volts_str = "nan"
                    load_current_str = "nan"

                # slower status poll
                now = time.time()
                if now - last_status_poll >= STATUS_POLL_PERIOD and hardware.e_load:
                    last_status_poll = now
                    try:
                        with hardware.eload_lock:
                            load_stat_func = hardware.e_load.query("FUNC?").strip()
                            load_stat_curr = hardware.e_load.query("CURR?").strip()
                            load_stat_imp = hardware.e_load.query("INP?").strip()
                            load_stat_res = hardware.e_load.query("RES?").strip()
                            load_stat_short = hardware.e_load.query("INP:SHOR?").strip()
                    except pyvisa.VisaIOError as e:
                        print(f"PyVISA status poll error: {e}", file=sys.stderr)

                if is_number(load_volts_str) and is_number(load_current_str):
                    load_volts = float(load_volts_str) * 1000.0
                    load_current = float(load_current_str) * 1000.0
                    load_volts_mV = int(round(load_volts))
                    load_current_mA = int(round(load_current))

                    data = [
                        load_volts_mV & 0xFF,
                        (load_volts_mV >> 8) & 0xFF,
                        load_current_mA & 0xFF,
                        (load_current_mA >> 8) & 0xFF,
                        0, 0, 0, 0
                    ]
                    msg = can.Message(
                        arbitration_id=ELOAD_READ_ID,
                        data=data,
                        is_extended_id=True
                    )
                    try:
                        cbus.send(msg)
                    except can.CanError:
                        print("E-Load message NOT sent")
                else:
                    print("Received NaN from e-load measurements")

            # Prepare display lines
            line_sep = "*" * 60
            if hardware.e_load:
                visa_id = hardware.e_load.resource_name
                dis_lines = [
                    line_sep,
                    "* ELOAD ID - " + visa_id,
                    "* ENABLE: " + (load_stat_imp or ""),
                    "* MODE: " + (load_stat_func or ""),
                    "* CURRENT SETTING: " + (load_stat_curr or ""),
                    "* RESISTANCE SETTING: " + (load_stat_res or ""),
                    "* SHORT ENABLED: " + (load_stat_short or ""),
                    f"* VOLTS: {load_volts_mV/1000:.3f} V",
                    f"* CURRENT: {load_current_mA/1000:.3f} A",
                    "* METER ID - " + (hardware.mmeter_id or ""),
                    f"* CURRENT: {meter_current_mA/1000:.3f} A",
                    f"* K1: {GPIO_K1}",
                    line_sep,
                ]
            else:
                dis_lines = [
                    line_sep,
                    "* ELOAD - NOT DETECTED",
                    f"* METER - CURRENT: {meter_current_mA/1000:.3f} A",
                    f"* METER - MODE: {meter_mode_str} {meter_range_str}",
                    line_sep,
                ]

            update_display(dis_lines)
            time.sleep(0.02)

    except KeyboardInterrupt:
        print("\nInterrupted by user. Starting graceful shutdown...")
    finally:
        stop_event.set()
        if receiver_thread:
            receiver_thread.join()
            print("Receiver thread stopped.")
        if cbus:
            cbus.shutdown()
            print("CAN bus shut down.")
        hardware.close_devices()
        shutdown_can_interface(CAN_CHANNEL)
        print("Shutdown complete. Exiting.")


if __name__ == "__main__":
    main()
