#!/home/j/roi/bin/python
import can
import serial
import subprocess
import threading
import time
import pyvisa
import sys
from gpiozero import LED
import shutil

# --- Constants ---
# Hardware identifiers
MULTI_METER_PATH = '/dev/ttyUSB0'
MULTI_METER_BAUD = 38400
ELOAD_VISA_ID = "USB0::11975::34816::802197042747610014::0::INSTR"

# CAN bus configuration
CAN_CHANNEL = "can1"
CAN_BITRATE = 250000
LOAD_CTRL_ID = 0x0CFF0400
RLY_CTRL_ID = 0x0CFF0500
ELOAD_READ_ID = 0x0CFF0003
MMETER_READ_ID = 0x0CFF0004

# Pin configuration
K1_PIN_BCM = 26
GPIO_K1 = LED(K1_PIN_BCM)

# --- Class for Hardware Management ---
class HardwareManager:
    """Manages communication and state for the e-load and multimeter."""

    def __init__(self):
        self.e_load_remote: int = 0
        self.e_load_enabled: int = 0
        self.e_load_mode: int = 0
        self.e_load_short: int = 0
        self.e_load_csetting: int = 0
        self.e_load_rsetting: int = 0
        self.pload_volts: float = 0.0
        self.pload_current: float = 0.0
        self.multi_meter = None
        self.e_load = None
        self.resource_manager = None
        self.eload_lock = threading.Lock()
        self.can_lock = threading.Lock()

    def initialize_devices(self) -> None:
        """Initializes the multi-meter and e-load."""
        self._initialize_multimeter()
        self._initialize_eload()

    def _initialize_multimeter(self) -> None:
        """Initializes the multimeter via serial connection."""
        try:
            mmeter = serial.Serial(MULTI_METER_PATH, MULTI_METER_BAUD, timeout=1)
            mmeter.write(b'*IDN?\n')
            response = mmeter.readline().decode().strip()
            print(f"MULTI-METER ID: {response}")
            self.multi_meter = mmeter
        except (serial.SerialException, IOError) as e:
            print(f"Failed to communicate with multi-meter: {e}")
            self.multi_meter = None

    def _initialize_eload(self) -> None:
        """Initializes the e-load via pyvisa."""
        try:
            self.resource_manager = pyvisa.ResourceManager()
            eload = self.resource_manager.open_resource(ELOAD_VISA_ID)
            print(f"E-LOAD ID: {eload.query('*IDN?')}")
            print(f"Resetting {ELOAD_VISA_ID}")
            eload.write('*RST')
            eload.write('SYST:CLE')
            self.e_load = eload
        except Exception as e:
            print(f"An error occurred with the e-load via Resource Manager: {e}")
            self.e_load = None

    def close_devices(self) -> None:
        """Closes connections to all hardware devices."""
        if self.multi_meter:
            print("Closing multi-meter connection...")
            self.multi_meter.close()
        if self.e_load:
            print("Closing e-load connection...")
            self.e_load.close()
        if self.resource_manager:
            print("Closing resource manager...")
            self.resource_manager.close()

# --- Main Functions ---
def setup_can_interface(channel: str, bitrate: int) -> can.BusABC | None:
    """Configures and brings up the CAN interface."""
    try:
        subprocess.run(
            ["sudo", "ip", "link", "set", channel, "up", "type", "can", f"bitrate", f"{bitrate}"],
            check=True
        )
        print(f"CAN interface {channel} is up with bitrate {bitrate}.")
        return can.interface.Bus(interface='socketcan', channel=channel, bitrate=bitrate)
    except subprocess.CalledProcessError as e:
        print(f"Failed to bring up CAN interface: {e}")
        return None
    except can.CanError as e:
        print(f"Failed to connect to CAN bus: {e}")
        return None

def shutdown_can_interface(channel: str) -> None:
    """Brings down the CAN interface."""
    try:
        subprocess.run(["sudo", "ip", "link", "set", channel, "down"], check=True)
        print(f"CAN interface {channel} is now down.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to bring down CAN interface: {e}")

def receive_can_messages(cbus: can.BusABC, hardware: HardwareManager, stop_event: threading.Event) -> None:
    """Continuously receives CAN messages and updates hardware state."""
    print("Receiver thread started. Listening for CAN messages...")
    while not stop_event.is_set():
        with hardware.can_lock:
            message = cbus.recv(timeout=1.0)
        
        if not message:
            continue

        if message.arbitration_id == RLY_CTRL_ID:
            GPIO_K1.on() if message.data[0] & 0x03 == 0x01 else GPIO_K1.off()
            continue

        if message.arbitration_id == LOAD_CTRL_ID:
            first_byte = message.data[0]

            # Update remote control state
            new_remote_state = 1 if first_byte & 0x03 == 0x01 else 0
            if hardware.e_load_remote != new_remote_state:
                hardware.e_load_remote = new_remote_state

            # Update enable state and send command
            new_enable_state = 1 if first_byte & 0x0C == 0x04 else 0
            if hardware.e_load_enabled != new_enable_state:
                hardware.e_load_enabled = new_enable_state
                command = "INP ON" if hardware.e_load_enabled else "INP OFF"
                #print(f"E-load cmd: {command}" + " " * 40, flush=True)
                if hardware.e_load:
                    with hardware.eload_lock:
                        hardware.e_load.write(command)

            # Update enable state and send command
            new_mode = 1 if first_byte & 0x30 == 0x10 else 0
            if hardware.e_load_mode != new_mode:
                hardware.e_load_mode = new_mode
                command = "FUNC RES" if hardware.e_load_mode else "FUNC CURR"
                #print(f"E-load cmd: {command}" + " " * 40, flush=True)
                if hardware.e_load:
                    with hardware.eload_lock:
                        hardware.e_load.write(command)

            # Update enable state and send command
            new_mode = 1 if first_byte & 0xC0 == 0x40 else 0
            if hardware.e_load_short != new_mode:
                hardware.e_load_short = new_mode
                command = "INP:SHOR ON" if hardware.e_load_short else "INP:SHOR OFF"
                #print(f"E-load cmd: {command}" + " " * 40, flush=True)
                if hardware.e_load:
                    with hardware.eload_lock:
                        hardware.e_load.write(command)
                        
            # Update current setting
            in_value = (message.data[3] * 256) + message.data[2]
            if hardware.e_load_csetting != in_value:
                hardware.e_load_csetting = in_value
                if hardware.e_load:
                    command = f"CURR {hardware.e_load_csetting / 1000}"
                    #print(f"E-load cmd: {command}")
                    with hardware.eload_lock:
                        hardware.e_load.write(command)
                        
            # Update resistance setting
            in_value = (message.data[5] * 256) + message.data[4]
            if hardware.e_load_rsetting != in_value:
                hardware.e_load_rsetting = in_value
                if hardware.e_load:
                    command = f"RES {hardware.e_load_rsetting / 1000}"
                    #print(f"E-load cmd: {command}")
                    with hardware.eload_lock:
                        hardware.e_load.write(command)
                        
def is_number(value: str) -> bool:
    """Checks if a string can be converted to a float."""
    try:
        float(value)
        return True
    except ValueError:
        return False
        
def update_display(line1, line2):
    # Get the number of terminal lines
    rows, _ = shutil.get_terminal_size()
    
    # Move the cursor to the bottom row, and clear the line
    sys.stdout.write(f"\033[{rows}H\033[K")
    
    # Write the two lines, moving the cursor up for the second line
    sys.stdout.write(f"\033[1A\033[K\r{line1}\n{line2}")
    sys.stdout.flush()
    # # Clear the entire screen and move the cursor to the top-left corner
    # sys.stdout.write('\033[2J\033[H')
    
    # # Print the two lines and flush the output buffer
    # sys.stdout.write(f"{line1}\n{line2}")
    # sys.stdout.flush()
    
def main() -> None:
    """Main execution function."""
    hardware = HardwareManager()
    stop_event = threading.Event()
    cbus = None
    receiver_thread = None
    load_volts = 0
    load_current = 0
    meter_current = 0
    load_volts_str = ""
    load_current_str = ""
    load_stat_func = ""
    load_stat_curr = ""
    load_stat_imp = ""
    load_stat_res = ""
    load_stat_short = ""
    #line1 = f"Eload V: {load_volts/1000:.3f} V, Eload I: {load_current/1000:.3f} A"
    #line2 = f"Meter I: {meter_current/1000:.3f} A"
    #print(f"{line1}\n{line2}")
    try:
        hardware.initialize_devices()
        cbus = setup_can_interface(CAN_CHANNEL, CAN_BITRATE)
        if not cbus:
            print("Exiting due to CAN interface setup failure.")
            return

        receiver_thread = threading.Thread(
            target=receive_can_messages,
            args=(cbus, hardware, stop_event),
            daemon=True
        )
        receiver_thread.start()

        while True:
            # Read from multi-meter and send to CAN
            if hardware.multi_meter:
                hardware.multi_meter.write(b'FETC?\n')
                response = hardware.multi_meter.readline().decode().strip()
                if is_number(response):
                    value = float(response)
                    value = max(0, value)
                    meter_current = int(value * 1000)
                    hb = meter_current % 256
                    lb = meter_current // 256
                    msg = can.Message(
                        arbitration_id=MMETER_READ_ID,
                        data=[hb, lb, 0, 0, 0, 0, 0, 0],
                        is_extended_id=True
                    )
                    try:
                        with hardware.can_lock:
                            cbus.send(msg)
                        #print(f"MMeter current: {meter_current:.3f} A", end='\r', flush=True)
                    except can.CanError:
                        print("Message NOT sent")

            # Read from e-load and send to CAN
            if hardware.e_load:
                try:
                    with hardware.eload_lock:
                        load_volts_str = hardware.e_load.query("MEAS:VOLT?").strip()
                        load_current_str = hardware.e_load.query("MEAS:CURR?").strip()
                        load_stat_func = hardware.e_load.query("FUNC?").strip()
                        load_stat_curr = hardware.e_load.query("CURR?").strip()
                        load_stat_imp = hardware.e_load.query("INP?").strip()
                        load_stat_res = hardware.e_load.query("RES?").strip()
                        load_stat_short = hardware.e_load.query("INP:SHOR?").strip()
                        
                except pyvisa.VisaIOError as e:
                    print(f"PyVISA communication error: {e}", file=sys.stderr)
                    time.sleep(1)
                    continue

                if is_number(load_volts_str) and is_number(load_current_str):
                    load_volts = float(load_volts_str) * 1000
                    load_current = float(load_current_str) * 1000
                    msg = can.Message(
                        arbitration_id=ELOAD_READ_ID,
                        data=[int(load_volts % 256), int(load_volts / 256),
                              int(load_current % 256), int(load_current / 256),
                              0, 0, 0, 0],
                        is_extended_id=True
                    )
                    try:
                        with hardware.can_lock:
                            cbus.send(msg)
                    except can.CanError:
                        print("Message NOT sent")
                else:
                    print("Recevied NAN")

            # Prepare new strings
            new_line1 = "EL_EN: " + load_stat_imp + " EL_M: " + load_stat_func + " EL_CUR: " + load_stat_curr + " EL_RES: " + load_stat_res + " EL_SHRT: " + load_stat_short
            new_line2 = f"EL_V: {load_volts/1000:.3f} V, EL_I: {load_current/1000:.3f} A, MM_I: {meter_current/1000:.3f} A"
            # Call the update function
            update_display(new_line1, new_line2)            
            time.sleep(0.02)

    except KeyboardInterrupt:
        print("\nInterrupted by user. Starting graceful shutdown...")
    finally:
        stop_event.set()
        if receiver_thread:
            receiver_thread.join()
            print("Receiver thread stopped.")
        if cbus:
            cbus.shutdown()
            print("CAN bus shut down.")
        hardware.close_devices()
        shutdown_can_interface(CAN_CHANNEL)
        print("Shutdown complete. Exiting.")

if __name__ == "__main__":
    main()
